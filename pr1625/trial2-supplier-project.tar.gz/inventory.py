#!/usr/bin/env python3
"""Returns-aware inventory summary for a small parts store.

Reads a CSV of (item, quantity, status) rows, prints a stock summary, and
writes the same summary to a JSON report. Standard library only.

Usage:
    python3 inventory.py [INPUT.csv] [--output report.json] [--low-stock N]
        [--reorder-csv PATH]
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

# Sellable stock is an allow-list: any status not named here (quarantined,
# damaged, a typo, ...) is excluded by default rather than silently sold.
SELLABLE_STATUSES = {"available"}

# Units in these statuses are not sellable stock: they are out with a customer.
RETURNED_STATUSES = {"returned", "return", "refunded"}


def load_rows(path: str | Path) -> list[dict]:
    """Read the CSV and return rows as dicts with an int ``quantity``."""
    rows: list[dict] = []
    try:
        handle = open(path, newline="", encoding="utf-8")
    except OSError as exc:
        raise SystemExit(f"error: cannot read {path}: {exc}") from exc

    with handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
        missing = {"item", "quantity", "status"} - set(fieldnames)
        if missing:
            raise SystemExit(
                f"error: {path} is missing column(s): {', '.join(sorted(missing))}"
            )
        for line_no, row in enumerate(reader, start=2):
            item = (row.get("item") or "").strip()
            status = (row.get("status") or "").strip()
            raw_qty = (row.get("quantity") or "").strip()
            if not item and not raw_qty and not status:
                continue  # blank line
            try:
                quantity = int(raw_qty)
            except ValueError:
                raise SystemExit(
                    f"error: {path} line {line_no}: quantity {raw_qty!r} is not an integer"
                ) from None
            if quantity < 0:
                raise SystemExit(
                    f"error: {path} line {line_no}: quantity {raw_qty!r} is negative"
                )
            rows.append({"item": item, "quantity": quantity, "status": status})
    return rows


def is_available(row: dict) -> bool:
    """True when a row is sellable stock (status is on the sellable allow-list)."""
    return row["status"].strip().lower() in SELLABLE_STATUSES


def summarize(source: str | Path, rows: list[dict], low_stock: int | None = None) -> dict:
    """Build the report dict: per-line detail plus totals and status breakdown.

    The headline total is ``available_units`` - returns are reported
    separately and never counted as sellable. When ``low_stock`` is given, the
    report gains a reorder list of available items below that threshold.
    """
    by_status: dict[str, dict] = {}
    available_units = 0
    returned_units = 0

    for row in rows:
        qty = row["quantity"]
        status = row["status"]
        if is_available(row):
            available_units += qty
        elif status.strip().lower() in RETURNED_STATUSES:
            returned_units += qty
        bucket = by_status.setdefault(status, {"lines": 0, "units": 0})
        bucket["lines"] += 1
        bucket["units"] += qty

    report = {
        "source": str(source),
        "line_items": len(rows),
        "available_units": available_units,
        "returned_units": returned_units,
        "by_status": by_status,
        "items": rows,
    }
    if low_stock is not None:
        reorder = [r for r in rows if is_available(r) and r["quantity"] < low_stock]
        reorder.sort(key=lambda r: r["quantity"])
        report["low_stock_threshold"] = low_stock
        report["low_stock"] = reorder
    return report


def format_summary(report: dict) -> str:
    """Render the report as a plain-text table a colleague can read at a glance."""
    lines = [f"Inventory summary - {report['source']}", ""]
    lines.append(f"{'Item':<20} {'Qty':>6}  Status")
    lines.append("-" * 40)
    for row in report["items"]:
        lines.append(f"{row['item']:<20} {row['quantity']:>6}  {row['status']}")
    lines.append("-" * 40)
    lines.append(f"Available units: {report['available_units']:>6}")
    lines.append(f"Returned units:  {report['returned_units']:>6}")
    lines.append(f"Line items:      {report['line_items']:>6}")
    if report["by_status"]:
        lines.append("")
        lines.append("By status:")
        for status in sorted(report["by_status"]):
            bucket = report["by_status"][status]
            lines.append(
                f"  {status:<12} {bucket['units']:>6} units in {bucket['lines']} line(s)"
            )
    if "low_stock" in report:
        lines.append("")
        lines.append(
            f"Reorder list (available items below {report['low_stock_threshold']} units):"
        )
        if report["low_stock"]:
            for row in report["low_stock"]:
                lines.append(f"  {row['item']:<20} {row['quantity']:>6}")
        else:
            lines.append("  none")
    return "\n".join(lines)


def write_report(report: dict, path: str | Path) -> None:
    """Write the report dict to ``path`` as indented JSON."""
    Path(path).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


def write_reorder_csv(report: dict, path: str | Path) -> None:
    """Write the supplier reorder list to ``path`` as CSV.

    Columns are ``item,available,needed`` where ``available`` is the item's
    sellable quantity and ``needed = threshold - available``. Only available
    items below the threshold are exported (quarantined, returned and other
    non-sellable rows never appear), and rows are sorted by item name for
    stable diffing against a supplier's own list.
    """
    threshold = report["low_stock_threshold"]
    rows = sorted(report["low_stock"], key=lambda r: r["item"])
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["item", "available", "needed"])
        for row in rows:
            available = row["quantity"]
            writer.writerow([row["item"], available, threshold - available])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Print a stock summary and write a JSON inventory report."
    )
    parser.add_argument(
        "input", nargs="?", default="inventory.csv",
        help="input CSV (default: inventory.csv)",
    )
    parser.add_argument(
        "-o", "--output", default="report.json",
        help="JSON report path (default: report.json)",
    )
    parser.add_argument(
        "-l", "--low-stock", type=int, default=None, metavar="N",
        help="also list available items with fewer than N units (reorder list)",
    )
    parser.add_argument(
        "--reorder-csv", default=None, metavar="PATH",
        help="also export the supplier reorder list as CSV (requires --low-stock)",
    )
    args = parser.parse_args(argv)

    if args.reorder_csv is not None and args.low_stock is None:
        parser.error("--reorder-csv requires --low-stock N")

    report = summarize(args.input, load_rows(args.input), low_stock=args.low_stock)
    print(format_summary(report))
    write_report(report, args.output)
    print(f"\nWrote {args.output}")
    if args.reorder_csv is not None:
        write_reorder_csv(report, args.reorder_csv)
        print(f"Wrote {args.reorder_csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
