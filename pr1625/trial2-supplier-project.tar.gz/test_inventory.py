"""Tests for inventory.py. Run with: python3 -m unittest -v"""

import json
import tempfile
import unittest
from pathlib import Path

import inventory

SAMPLE = "item,quantity,status\nBolts,12,available\nNuts,7,available\nWashers,4,returned\n"


class InventoryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)

    def write_csv(self, text):
        path = self.dir / "inv.csv"
        path.write_text(text, encoding="utf-8")
        return path

    def test_load_rows_parses_quantity_as_int(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        self.assertEqual(
            rows,
            [
                {"item": "Bolts", "quantity": 12, "status": "available"},
                {"item": "Nuts", "quantity": 7, "status": "available"},
                {"item": "Washers", "quantity": 4, "status": "returned"},
            ],
        )

    def test_load_rows_rejects_non_integer_quantity(self):
        path = self.write_csv("item,quantity,status\nBolts,x,available\n")
        with self.assertRaises(SystemExit):
            inventory.load_rows(path)

    def test_load_rows_rejects_negative_quantity(self):
        path = self.write_csv("item,quantity,status\nBolts,-3,available\n")
        with self.assertRaises(SystemExit):
            inventory.load_rows(path)

    def test_main_bad_input_leaves_last_good_report_untouched(self):
        src = self.write_csv("item,quantity,status\nBolts,-3,available\n")
        out = self.dir / "out.json"
        out.write_text('{"kept": true}\n', encoding="utf-8")
        with self.assertRaises(SystemExit):
            inventory.main([str(src), "-o", str(out)])
        self.assertEqual(out.read_text(encoding="utf-8"), '{"kept": true}\n')

    def test_load_rows_rejects_missing_column(self):
        path = self.write_csv("item,quantity\nBolts,1\n")
        with self.assertRaises(SystemExit):
            inventory.load_rows(path)

    def test_headline_total_is_available_only(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        report = inventory.summarize("inv.csv", rows)
        self.assertEqual(report["available_units"], 19)
        self.assertEqual(report["returned_units"], 4)
        self.assertNotIn("total_units", report)  # returns never inflate the total
        self.assertEqual(report["by_status"]["available"], {"lines": 2, "units": 19})
        self.assertEqual(report["by_status"]["returned"], {"lines": 1, "units": 4})

    def test_format_summary_leads_with_available_and_shows_returns(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        text = inventory.format_summary(inventory.summarize("inv.csv", rows))
        self.assertIn("Available units:     19", text)
        self.assertIn("Returned units:       4", text)

    def test_low_stock_lists_only_available_below_threshold(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        report = inventory.summarize("inv.csv", rows, low_stock=10)
        # Bolts (12) is above the threshold; Washers (4) is below it but returned.
        self.assertEqual(report["low_stock_threshold"], 10)
        self.assertEqual(
            report["low_stock"],
            [{"item": "Nuts", "quantity": 7, "status": "available"}],
        )

    def test_low_stock_omitted_without_threshold(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        report = inventory.summarize("inv.csv", rows)
        self.assertNotIn("low_stock", report)
        self.assertNotIn("low_stock_threshold", report)

    def test_format_summary_prints_reorder_list(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        text = inventory.format_summary(inventory.summarize("inv.csv", rows, low_stock=10))
        self.assertIn("Reorder list", text)
        self.assertIn("Nuts", text)
        self.assertNotIn("Washers", text.split("Reorder list")[1])

    def test_quarantined_status_is_not_sellable(self):
        rows = inventory.load_rows(
            self.write_csv("item,quantity,status\nBolts,12,available\nClips,5,quarantined\n")
        )
        report = inventory.summarize("inv.csv", rows)
        self.assertEqual(report["available_units"], 12)
        # quarantined is not sellable and is not a return
        self.assertEqual(report["returned_units"], 0)
        self.assertEqual(report["by_status"]["quarantined"], {"lines": 1, "units": 5})

    def test_unknown_status_is_not_sellable(self):
        rows = inventory.load_rows(
            self.write_csv("item,quantity,status\nBolts,12,available\nWidget,9,damaged\n")
        )
        self.assertEqual(inventory.summarize("inv.csv", rows)["available_units"], 12)

    def test_low_stock_excludes_non_sellable(self):
        rows = inventory.load_rows(
            self.write_csv("item,quantity,status\nBolts,12,available\nClips,3,quarantined\n")
        )
        report = inventory.summarize("inv.csv", rows, low_stock=10)
        self.assertEqual(report["low_stock"], [])

    def test_write_report_round_trips_json(self):
        rows = inventory.load_rows(self.write_csv(SAMPLE))
        report = inventory.summarize("inv.csv", rows, low_stock=10)
        out = self.dir / "report.json"
        inventory.write_report(report, out)
        self.assertEqual(json.loads(out.read_text(encoding="utf-8")), report)

    def test_main_writes_requested_output(self):
        src = self.write_csv(SAMPLE)
        out = self.dir / "out.json"
        argv = [str(src), "-o", str(out), "--low-stock", "10"]
        self.assertEqual(inventory.main(argv), 0)
        written = json.loads(out.read_text(encoding="utf-8"))
        self.assertEqual(written["available_units"], 19)
        self.assertEqual([r["item"] for r in written["low_stock"]], ["Nuts"])


class ReorderCsvTest(unittest.TestCase):
    """--reorder-csv: supplier export of available items below the threshold."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)

    def write_csv(self, text):
        path = self.dir / "inv.csv"
        path.write_text(text, encoding="utf-8")
        return path

    def render(self, csv_text, threshold=10):
        rows = inventory.load_rows(self.write_csv(csv_text))
        report = inventory.summarize("inv.csv", rows, low_stock=threshold)
        out = self.dir / "supplier.csv"
        inventory.write_reorder_csv(report, out)
        return out.read_text(encoding="utf-8")

    def test_sample_row_is_item_available_needed(self):
        # available=7, threshold=10 -> needed=3
        self.assertEqual(
            self.render(SAMPLE),
            "item,available,needed\nNuts,7,3\n",
        )

    def test_never_exports_quarantined_or_returned(self):
        text = (
            "item,quantity,status\n"
            "Bolts,12,available\n"
            "Nuts,7,available\n"
            "Washers,4,returned\n"
            "Clips,5,quarantined\n"
        )
        out = self.render(text)
        self.assertEqual(out, "item,available,needed\nNuts,7,3\n")
        for gone in ("Washers", "Clips"):
            self.assertNotIn(gone, out)

    def test_sorted_by_item_name(self):
        text = (
            "item,quantity,status\n"
            "Zinc,2,available\n"
            "Bolts,1,available\n"
            "Nuts,7,available\n"
        )
        out = self.render(text)
        self.assertEqual(
            out,
            "item,available,needed\nBolts,1,9\nNuts,7,3\nZinc,2,8\n",
        )

    def test_threshold_boundary_is_exclusive(self):
        text = "item,quantity,status\nAt,10,available\nBelow,9,available\n"
        out = self.render(text, threshold=10)
        self.assertEqual(out, "item,available,needed\nBelow,9,1\n")

    def test_empty_reorder_list_is_header_only(self):
        text = "item,quantity,status\nBolts,12,available\n"
        self.assertEqual(self.render(text), "item,available,needed\n")

    def test_main_requires_low_stock(self):
        src = self.write_csv(SAMPLE)
        with self.assertRaises(SystemExit):
            inventory.main([str(src), "--reorder-csv", str(self.dir / "supplier.csv")])

    def test_main_writes_reorder_csv(self):
        src = self.write_csv(SAMPLE)
        out = self.dir / "supplier.csv"
        argv = [str(src), "-o", str(self.dir / "out.json"),
                "--low-stock", "10", "--reorder-csv", str(out)]
        self.assertEqual(inventory.main(argv), 0)
        self.assertEqual(out.read_text(encoding="utf-8"), "item,available,needed\nNuts,7,3\n")

    def test_negative_input_writes_no_reorder_csv(self):
        src = self.write_csv("item,quantity,status\nBolts,-3,available\n")
        out = self.dir / "supplier.csv"
        with self.assertRaises(SystemExit):
            inventory.main([str(src), "-o", str(self.dir / "out.json"),
                            "--low-stock", "10", "--reorder-csv", str(out)])
        self.assertFalse(out.exists())

    def test_bundled_sample_exports_only_nuts(self):
        out = self.dir / "supplier.csv"
        sample = Path(inventory.__file__).resolve().parent / "inventory.csv"
        argv = [str(sample), "-o", str(self.dir / "out.json"),
                "--low-stock", "10", "--reorder-csv", str(out)]
        self.assertEqual(inventory.main(argv), 0)
        self.assertEqual(out.read_text(encoding="utf-8"), "item,available,needed\nNuts,7,3\n")


if __name__ == "__main__":
    unittest.main()
