# Returns-aware inventory report

Build a small inventory summary from a CSV of parts.

`inventory.py` reads a CSV with the columns `item,quantity,status`, prints a
stock summary to the terminal, and writes the same summary to `report.json`.
It uses only the Python standard library, so there is nothing to install.

## Run it

Summarize the bundled sample (`inventory.csv` -> `report.json`):

    python3 inventory.py

Point it at another file, or another output path:

    python3 inventory.py my_parts.csv --output out/report.json

Get a reorder list of available items below a threshold:

    python3 inventory.py --low-stock 10

Export that reorder list as a CSV for a supplier, alongside the threshold:

    python3 inventory.py --low-stock 10 --reorder-csv supplier.csv

`--reorder-csv` requires `--low-stock`; on the bundled sample with `N=10`,
`supplier.csv` holds a single line, `Nuts,7,3`.

### Corrected supplier order (target 15 units)

The supplier decision is a target stock of **15 units**, and only sellable
(`available`) stock counts toward it. Regenerate the corrected purchase order
from the bundled sample, writing the JSON summary to its own file so the
existing `report.json` is preserved:

    python3 inventory.py inventory.csv --low-stock 15 \
        --reorder-csv purchase-order.csv --output purchase-order-report.json

With `N=15` both available items are below target, so `purchase-order.csv`
holds (sorted by item name):

    item,available,needed
    Bolts,12,3
    Nuts,7,8

`Washers` (returned) and `Clips` (quarantined) are not sellable stock and never
appear in the order.

## Input format

    item,quantity,status
    Bolts,12,available
    Nuts,7,available
    Washers,4,returned

`quantity` must be a whole number, zero or greater; a negative quantity is
rejected with a line-numbered error and no report is written. A row is
sellable only when its status is `available`; any other status (quarantined,
damaged, a typo, ...) is excluded from available stock by default and shown
only in the `by_status` breakdown. Rows with a status of `returned`,
`return`, or `refunded` are counted as returned units and excluded from
available stock. The headline total is available units only - returned
parts are shown separately and are never counted as sellable.

## Output

The terminal shows a per-item table, the available/returned totals, and a
breakdown by status:

    Inventory summary - inventory.csv

    Item                    Qty  Status
    ----------------------------------------
    Bolts                    12  available
    Nuts                      7  available
    Washers                   4  returned
    ----------------------------------------
    Available units:     19
    Returned units:       4
    Line items:           3

With `--low-stock 10`, a reorder list is appended containing only available
items below the threshold:

    Reorder list (available items below 10 units):
      Nuts                      7

The supplier CSV has the columns `item,available,needed`, where `available`
is the item's sellable quantity and `needed = N - available`. It lists only
available items below the threshold - quarantined, returned and other
non-sellable rows never appear - and is sorted by item name:

    item,available,needed
    Nuts,7,3

`report.json` holds the same numbers in a machine-readable form:
`available_units` (the headline total), `returned_units`, per-line `items`,
a `by_status` breakdown, and - when `--low-stock` is used -
`low_stock_threshold` and a `low_stock` list of the items to reorder.

## Tests

    python3 -m unittest -v
