# Daily order reporting

Summarizes `orders.csv` by currency into a JSON report. Cancelled and
refunded orders are excluded; totals use exact decimal arithmetic; currencies
are sorted. Standard library only, no dependencies.

## Commands

Run from this directory.

Produce the report (`report.json`):

```
python3 summarize.py
```

Run the regression tests:

```
python3 -m unittest test_summarize -v
```

Export the report and write `export-receipt.json`:

```
python3 trace_export.py
```

Write the report to a chosen path:

```
python3 summarize.py orders.csv final-sales.json
```

## Output

`report.json` is a currency-sorted list of `{"currency", "count", "total"}`.
Totals are strings so the decimal value is exact.

## Verified result

For the current `orders.csv`:

| currency | count | total |
|---|---|---|
| EUR | 2 | 5.30 |
| USD | 2 | 19.75 |

`export-receipt.json` matches this report.
