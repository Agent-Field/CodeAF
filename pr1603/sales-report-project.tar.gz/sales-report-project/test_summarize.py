#!/usr/bin/env python3
"""Regression test: summarize.orders/orders.csv reports paid orders only.

Guards the contract that cancelled AND refunded rows are excluded
(A3 USD cancelled, A6 USD refunded) and that totals are exact strings.
"""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent


class OrderReportTest(unittest.TestCase):
    def test_orders_csv_paid_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "report.json"
            subprocess.run(
                [sys.executable, str(HERE / "summarize.py"),
                 str(HERE / "orders.csv"), str(out)],
                check=True, capture_output=True, text=True,
            )
            report = json.loads(out.read_text())

        self.assertEqual(report, [
            {"currency": "EUR", "count": 2, "total": "5.30"},
            {"currency": "USD", "count": 2, "total": "19.75"},
        ])


if __name__ == "__main__":
    unittest.main()
