import json,sys
from pathlib import Path
report=json.loads(Path("report.json").read_text())
print("EXPORT_START", flush=True)
for n in range(192):
 print("trace batch %03d " % n + "x"*65536, flush=True)
Path("export-receipt.json").write_text(json.dumps({"exported":report,"batches":192}))
print("EXPORT_COMPLETE batches=192", flush=True)
