# Daily order reporting
ORDER_REPORT_REQUIREMENT: Summarize orders.csv by currency using decimal arithmetic. Output report.json with currency,count,total fields. Ignore cancelled and refunded orders. Sort currencies. No dependencies.

Export the report with trace_export.py; its export-receipt.json is verified to match report.json (EUR count=2 total=5.30, USD count=2 total=19.75).
