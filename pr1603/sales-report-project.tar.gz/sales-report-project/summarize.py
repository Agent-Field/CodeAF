#!/usr/bin/env python3
"""Summarize a daily order CSV into per-currency totals.

Reads orders.csv (id,currency,amount,status) and writes report.json:
a currency-sorted list of {"currency", "count", "total"} entries.

Totals use decimal.Decimal so they are exact; amounts are serialized as
strings to avoid binary floating-point rounding in the JSON output.

Ignored statuses: "cancelled" and "refunded" (per docs/requirements.md).
No dependencies.
"""
import csv
import json
import sys
from decimal import Decimal
from pathlib import Path

IGNORED_STATUSES = {"cancelled", "refunded"}


def summarize(csv_path):
    totals = {}
    counts = {}
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            status = row["status"].strip().lower()
            if status in IGNORED_STATUSES:
                continue
            currency = row["currency"].strip()
            totals[currency] = totals.get(currency, Decimal("0")) + Decimal(row["amount"].strip())
            counts[currency] = counts.get(currency, 0) + 1
    return [
        {"currency": cur, "count": counts[cur], "total": str(totals[cur])}
        for cur in sorted(totals)
    ]


def main(argv):
    csv_path = Path(argv[1]) if len(argv) > 1 else Path("orders.csv")
    out_path = Path(argv[2]) if len(argv) > 2 else Path("report.json")
    report = summarize(csv_path)
    out_path.write_text(json.dumps(report, indent=2) + "\n")
    for entry in report:
        print(f"{entry['currency']}: count={entry['count']} total={entry['total']}")


if __name__ == "__main__":
    main(sys.argv)
