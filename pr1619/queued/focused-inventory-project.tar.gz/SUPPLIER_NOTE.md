# Supplier decision

- **Target stock: 15 units.** The reorder threshold is 15, not 10.
- **Only available stock counts.** `available` is the sole sellable status;
  returned, quarantined, damaged and otherwise non-sellable rows never count
  toward stock or toward the reorder calculation.

Consequence: a reorder list must list only `available` items below 15 units,
and `needed = 15 - available`.
